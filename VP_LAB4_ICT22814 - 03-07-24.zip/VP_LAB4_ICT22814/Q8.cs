﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VP_LAB4_ICT22814
{

    public class MathHelper
    {
        //Static Method
        public static int Add(int num1, int num2)
        {
            return num1 + num2;
        }
    }


    internal class Q8
    {
        static void Main(string[] args)
        {
            int sum = MathHelper.Add(10, 15);
            Console.WriteLine(sum);

            Console.ReadKey();
        }
    }
}
