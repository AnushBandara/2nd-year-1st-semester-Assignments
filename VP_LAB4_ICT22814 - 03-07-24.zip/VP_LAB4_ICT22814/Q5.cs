﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VP_LAB4_ICT22814
{

    //IMoveable Interface
    public interface IMovable
    {
        void move();
    }

    class Car : IMovable
    {
        public void move()
        {
            Console.WriteLine("The car is moving...");
        }
    }

    class Plane : IMovable
    {
        public void move()
        {
            Console.WriteLine("The plane is moving...");
        }
    }

    internal class Q5
    {
        static void Main(string[] args)
        {
            Car car1 = new Car();
            Car car2 = new Car();
            Plane plane1 = new Plane();
            Plane plane2 = new Plane();

            //List of IMoveable objects
            IMovable[] moveableVehcals = { car1, car2, plane1, plane2};

            //Moving each object in the list
            foreach(IMovable vehical in moveableVehcals)
            {
                vehical.move();
            }

            Console.ReadKey();

        }
    }
}
