﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VP_LAB4_ICT22814
{
    internal class Q9
    {
        static void Main(string[] args)
        {

            try
            {
                Console.Write("Enter the num 1: ");
                int num1 = Int32.Parse(Console.ReadLine());

                Console.Write("Enter the num 2: ");
                int num2 = Int32.Parse(Console.ReadLine());

                int answer = num1 / num2;

                Console.WriteLine(num1 + " / " + num2 + " = " + answer);


            }
            catch(DivideByZeroException ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
            }
            catch(FormatException ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Unexpected Error : {ex.Message}");
            }

            Console.ReadKey();

        }
    }
}
