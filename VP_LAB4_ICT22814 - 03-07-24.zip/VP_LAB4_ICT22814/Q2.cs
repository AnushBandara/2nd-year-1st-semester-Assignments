﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VP_LAB4_ICT22814
{
    internal class Q2
    {
        static void Main(string[] args)
        {
            Console.Write("Enter your marks: ");
            int mark = int.Parse(Console.ReadLine());

            char grade = letterGrader(mark);

            Console.Write("Ypur grade is : " + grade);

            Console.ReadKey();
        }

        static char letterGrader(int mark)
        {
            if (mark > 90)
            {
                return 'A';
            }
            else if (mark > 80)
            {
                return 'B';
            }
            else if (mark > 70)
            {
                return 'C';
            }
            else if (mark > 60)
            {
                return 'D';
            }
            else
            {
                return 'F';
            }
        }
    }
}
