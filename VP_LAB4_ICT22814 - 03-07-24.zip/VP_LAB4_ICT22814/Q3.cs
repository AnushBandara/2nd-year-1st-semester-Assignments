﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VP_LAB4_ICT22814
{
    internal class Q3
    {
        static void Main(string[] args)
        {
            double num1, num2, answer;
            char operation;
            while (true)
            {
                Console.Write("Enter your first number: ");
                num1 = double.Parse(Console.ReadLine());

                Console.Write("Enter your operation: ");
                operation = char.Parse(Console.ReadLine());

                Console.Write("Enter your second number: ");
                num2 = double.Parse(Console.ReadLine());

                answer = 0;

                switch (operation)
                {
                    case '+':
                        answer = num1+num2;
                        break;

                    case '-':
                        answer = num1 - num2;
                        break;

                    case '*':
                        answer = num1 * num2;
                        break;

                    case '/':

                        //Zero divisio handeling
                        if (num2 != 0)
                        {
                            answer = num1 / num2;
                        }
                        else
                        {
                            Console.WriteLine("You enterd 0 for num2 and, it caused 0 division error !\nPlease input correct data again.\n\n");
                            continue;
                        }
                        break;

                    default:
                        Console.WriteLine("You havent enterd a correct operation !\nPlease input correct data again.\n\n");
                        continue;
                }



                Console.WriteLine(num1 + " " + operation + " " + num2 + " = " + answer);
                
                Console.Write("\nDo you have any other calculations to do? (Y/N): ");
                if (Console.ReadKey().Key != ConsoleKey.Y)
                {
                    break;
                }
                Console.WriteLine("\n\n");

            }
        }
    }
}
