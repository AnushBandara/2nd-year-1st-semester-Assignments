﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VP_LAB4_ICT22814
{
    internal class Q4
    {
        static void Main(string[] args)
        {
            Console.Write("Enter your temperature in Celsius: ");
            double temperature = double.Parse(Console.ReadLine());

            if (temperature < -10)
            {
                Console.WriteLine("It is Very Cold.");
            }
            else if(temperature <= 0)
            {
                Console.WriteLine("It is Cold.");
            }
            else if(temperature <= 10)
            {
                Console.WriteLine("It is Cool.");
            }
            else if(temperature <= 20)
            {
                Console.WriteLine("It is Moderate.");
            }
            else if(temperature > 20)
            {
                Console.WriteLine("It is Warm.");
            }

            Console.ReadKey();
        }
    }
}
