﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VP_LAB4_ICT22814
{

    public class BankAccount
    {
        private double blance;
        private string accountNumber;

        public BankAccount(string accountNumber, double blance)
        {
            this.blance = blance;
            this.AccountNumber = accountNumber;
        }

        //Private setter
        public string AccountNumber { get; private set; }



        public double Deposite(double amount)
        {
            blance += amount;
            Console.WriteLine(amount + " has been added to " + accountNumber + " account");
            return blance;
        }

        public double Withdraw(double amount)
        {
            if(blance-amount > 0)
            {
                blance -= amount;
                Console.WriteLine(amount + " has been deduct from " + accountNumber + " account");
                return blance;
            }
            else
            {
                Console.WriteLine("Insuficient balance at " + accountNumber + " account");
                return blance;
            }
        }


    }

    internal class Q6
    {
        static void Main(string[] args)
        {
            BankAccount account1 = new BankAccount("204526", 500000);

            Console.WriteLine("Account blance : "+ account1.Deposite(100000)+"\n\n");
            Console.WriteLine("Account blance : " + account1.Withdraw(100000));

            Console.ReadKey();

        }
    }
}
