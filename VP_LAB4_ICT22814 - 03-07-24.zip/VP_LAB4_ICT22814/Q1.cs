﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VP_LAB4_ICT22814
{
    internal class Q1
    {
        static void Main(string[] args)
        {
            Console.Write("Enter your character : ");
            char character = char.Parse(Console.ReadLine());

            bool charStatus = isVowel(character);

            if (charStatus == true)
            {
                Console.WriteLine(character + " is a vowel.");
            }
            else
            {
                Console.WriteLine(character + " is a consonant.");
            }

            Console.ReadKey();


        }


        static bool isVowel(char character)
        {
            //Convertig every character to lower case before checkig is it a vowel.
            character = char.ToLower(character);

            if (character == 'a' || character == 'e' || character == 'i' || character == 'o' || character == 'u')
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }

}
