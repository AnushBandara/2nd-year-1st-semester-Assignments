//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {

        double [] list = {12,45,23,67,45,90}; //The array to check for max
        System.out.println(MaxFinder(list)); //Printing the max value
    }

    public static double MaxFinder(double[] inputList){
        double max = inputList[0]; //Set the max value to the first element.

        for (int i = 0; i < inputList.length; i++) {
            if(max < inputList[i]){
                max = inputList[i]; //check each value if it is bigger than the current max value.
            }
        }

        return max;
    }
}