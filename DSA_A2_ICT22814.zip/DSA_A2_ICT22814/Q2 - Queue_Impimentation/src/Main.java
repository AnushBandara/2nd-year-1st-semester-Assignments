//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {

        Queue q1 = new Queue(4); //Creating the queue

        //Adding elements to the queue in Order
        q1.Enqueue(10);
        q1.Enqueue(20);
        q1.Enqueue(30);

        //taking out the elements as the order they came in
        System.out.println(q1.Dequeue());
        System.out.println(q1.Dequeue());
        System.out.println(q1.Dequeue());
    }
}

class Queue{
    private int front, rear, maxLength;
    private double [] queueArray;

    Queue(int maxLength){
        this.maxLength = maxLength;
        queueArray = new double[maxLength];
        front = rear = -1;
    }

    void Enqueue(double element){

        if(rear < maxLength){
            rear++;
            queueArray[rear] = element; //Adding a element to the rear
        }else{
            System.out.println("The queue is full."); //Error message
        }
    }

    double Dequeue(){
        if(front < rear) {
            front++;
            return queueArray[front]; //Sending the elemet from the front
        }else {
            System.out.println("The queue is empty"); //Error message
            return Double.MIN_VALUE;
        }
    }

}