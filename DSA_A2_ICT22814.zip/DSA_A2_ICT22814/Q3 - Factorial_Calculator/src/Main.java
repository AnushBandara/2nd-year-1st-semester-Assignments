//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {

        System.out.println(Factorial(4)); //Printing the factorial output
    }

    public static int Factorial(int number){
        int out = 1;
        if(number > 0){
            out = Factorial(number-1); //The recursion
        }else{
            return out;
        }
        out *= number;
        return out;
    }
}