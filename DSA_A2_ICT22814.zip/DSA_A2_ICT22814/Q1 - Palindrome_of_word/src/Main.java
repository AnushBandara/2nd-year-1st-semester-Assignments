public class Main {
    public static void main(String[] args) {

        String word = "civic"; //The word to be checked

        Stack sWord = new Stack(word.length()); //Creating the stack

        for (int i = 0; i < word.length(); i++) {
            sWord.Push(word.charAt(i)); //Pushing each element to the stack
        }

        boolean palindromState = true;

        for (int i = 0; i < word.length(); i++) {
            if (word.charAt(i) != sWord.Pop()){
                palindromState = false; //Check each letter for match
            }
        }

        if (palindromState == true) {
            System.out.println(word + " is a Palindrom");
        }else{
            System.out.println(word + " is NOT a Palindrom");
        }
    }
}


//The stack class
class Stack{
    private int maxSize; //To save the height of the stack
    private Character [] stackArray; // the stack
    private int top; //The index of the top element

    Stack(int maxSize){
        this.maxSize = maxSize;
        stackArray = new Character[maxSize];
        top = -1;
    }

    void Push(Character element){
        if (top < maxSize) {
            top++;
            //If the stack isn't full, add ana element to the top of the stack.
            stackArray[top] = element;

        }else{
            //If stack is full, print this error message
            System.out.println("The stack is full.");
        }
    }

    Character Peek(){
        if(top > -1){
            //Just show the top element of the stack.
            return stackArray[top];
        }else{
            //If the stack is empty, show the error and return null
            System.out.println("The stack is empty.");
            return null;
        }
    }

    Character Pop(){
        if(top > -1){
            top--;
            //remove the top element from the stack and send it out.
            return stackArray[top+1];
        }else{
            //If the stack is empty, show the error and return null
            System.out.println("The stack is empty.");
            return null;
        }
    }


}