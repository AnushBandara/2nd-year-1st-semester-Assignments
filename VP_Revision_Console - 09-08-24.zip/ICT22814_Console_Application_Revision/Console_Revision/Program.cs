﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Revision
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter the total number of days the book is returned late: ");
            int lateDays = int.Parse(Console.ReadLine());

            int fine;

            if (lateDays <= 5 )
            {
                Console.WriteLine("There is no fine for you.");
            }
            else if(lateDays <= 10 )
            {
                fine = lateDays * 5;
                Console.WriteLine($"Your fine is : Rs.{fine}");
            }
            else if(lateDays <= 30 )
            {
                fine = 25 + (lateDays - 5) * 10;
                Console.WriteLine($"Your fine is : Rs.{fine}");
            }
            else if (lateDays > 30)
            {
                fine = 25 + 200 + ((lateDays - 25) * 15);
                Console.WriteLine("Your membership has been canceled.");
                Console.WriteLine($"Your fine is : Rs.{fine}");
            }

            Console.ReadKey();
        }
    }
}
