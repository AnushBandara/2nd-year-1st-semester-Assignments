﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VP_LAB6_ICI22814
{
    public partial class Q1 : Form
    {
        public Q1()
        {
            InitializeComponent();
        }

        private void btnGenerate_Click(object sender, EventArgs e)
        {
            string nic = txtbNic.Text;
            string year = "";
            string middle = "";


            //Older NICs
            if ((nic.Count(char.IsDigit) == 9) && (nic.EndsWith("V") == true) && (nic[2] != 4 && nic[2] != 9))
            {
                year = "19" + nic.Substring(0, 2);
                middle = nic.Substring(2, 3);
            }
            //Newer NICs
            else if (nic.Count(char.IsDigit) == 12)
            {
                year = nic.Substring(0, 4);
                middle = nic.Substring(4, 3);
            }
            //Invalid NICs
            else
            {
                MessageBox.Show("Please enter a correct NIC number !", "Error.");
                txtbNic.Text=String.Empty;
                return;
            }

            //Drawing outputs

            //Year
            lblYear.Text = year;
            
            //Gender
            if(int.Parse(middle) > 500)
            {
                lblGender.Text = "Female";
            }
            else
            {
                lblGender.Text = "Male";
            }

            DateTime birthday = new DateTime(int.Parse(year), 1, 1).AddDays(int.Parse(middle)-1);
            //Month
            lblMonth.Text = birthday.ToString("MMMM");
            //Date
            lblDate.Text = birthday.Day.ToString();




        }
    }
}
