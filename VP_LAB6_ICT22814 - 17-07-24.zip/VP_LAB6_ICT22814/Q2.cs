﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VP_LAB6_ICI22814
{
    public partial class Q2 : Form
    {
        public Q2()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            DateTime birthDay = dtpBirtday.Value;
            DateTime currentDay = dtpCurrentdate.Value;

            TimeSpan timeDif = currentDay - birthDay;

            int years = (int)Math.Floor(timeDif.TotalDays / 365.25);
            lblYears.Text = years.ToString();

            int months = (int)Math.Floor((timeDif.TotalDays % 365.5)/ 30.436875);
            lblMonths.Text = months.ToString();

            int dates = (int)Math.Floor((timeDif.TotalDays % 365.5) % 30.436875);
            lblDates.Text = dates.ToString();


            int days = timeDif.Days;
            lblDays.Text = days.ToString();

            int weeks = (int)Math.Floor(days / 7.0);
            lblWeeks.Text = weeks.ToString();

            int hours = (int)Math.Floor((days / 24.0));
            lblHours.Text = hours.ToString();

            int minutes = hours * 60;
            lblMinutes.Text = minutes.ToString();

            int seconds = minutes * 60;
            lblSeconds.Text = seconds.ToString();

        }
    }
}
