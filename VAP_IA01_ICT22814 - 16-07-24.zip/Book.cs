﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Web;

namespace Library_Management_System
{
    internal static class Book
    {
        //Current directory
        static string workingDirectory = Environment.CurrentDirectory;
        
        static string filePath = Path.Combine(workingDirectory, "books.csv");
        static string header = "Book ID,Book Name,ISBN,Author,State\n";

        public static void AddBook()
        {
            //Interface
            string[] inputList = CL_Interface.AddBookI();

            string data = inputList[0] + "," + inputList[1] + "," + inputList[2] + "," + inputList[3] + ",1";
            List<string> writingData = new List<string>();
            writingData.Add(data);
            
            //Saving the book in books.csv file
            Csv_RW.Csv_Writer(filePath, header, writingData, $"\"{inputList[1]}\"");

            //Save the action to the log
            Logger.Log(1, $"{inputList[0]} book is added to the system.");



        }

        public static void IsueBook()
        {
            //Interface
            String[] inputList = CL_Interface.IssueBookI();

            //Checking for the book and change the status to the memberId who barrowed the book.
            List<string> lines = Csv_RW.Csv_Reader(filePath);
            
            string[] line_list = new string[5];
            int counter = 0;
            bool found = false;


            foreach (string line in lines)
            {
                line_list = line.Split(',');
                counter++;
                if (line_list[0] == inputList[1])
                {
                    line_list[4] = inputList[0];
                    found = true;
                    break;
                }
            }

            if (found)
            {
                lines.RemoveAt(counter - 1);
                string append_line = string.Join(",", line_list);
                lines.Add(append_line);

                //Saving the data again
                Csv_RW.Csv_Writer(filePath, header, lines, "book issueing", true);
            }
            else
            {
                Console.WriteLine("The book is not in the system.");
            }

            //Save the action to the log
            Logger.Log(3, $"{inputList[1]} book is issued to the {inputList[0]} member.");


        }

        public static void ReturnBook()
        {
            //Interface
            String[] inputList = CL_Interface.ReturnBookI();

            //Checking for the book and change the status to 1
            List<string> lines = Csv_RW.Csv_Reader(filePath);

            string[] line_list = new string[5];
            int counter = 0;
            bool found = false;


            foreach (string line in lines)
            {
                line_list = line.Split(',');
                counter++;
                if (line_list[0] == inputList[0])
                {
                    line_list[4] = "1";
                    found = true;
                    break;
                }
            }

            if (found)
            {
                lines.RemoveAt(counter - 1);
                string append_line = string.Join(",", line_list);
                lines.Add(append_line);

                //Saving the data again
                Csv_RW.Csv_Writer(filePath, header, lines, "book returning", true);
            }
            else
            {
                Console.WriteLine("The book is not in the system.");
            }

            //Save the action to the log
            Logger.Log(4, $"{inputList[0]} book is retturned to the system.");


        }

        public static void IssuedBooks()
        {
            CL_Interface.IssuedBooksI();

            List<string> lines = Csv_RW.Csv_Reader(filePath);
            lines.RemoveAt(0);
            string[] line_list = new string[5];
            List<string> writingData = new List<string>();

            foreach (string line in lines)
            {
                line_list = line.Split(',');
                if (line_list[4] != "1")
                {
                    writingData.Add(string.Join(",", line_list));
                    Console.WriteLine($"{line_list[0]} - {line_list[1]} - to{line_list[4]}");
                }
            }


            string issued_book_list_path = Path.Combine(workingDirectory, $"issued books {DateTime.Now.ToString("yyyy-MM-dd h:mm:ss tt")}.csv");

            Csv_RW.Csv_Writer(issued_book_list_path, header, writingData, $"\"issued books {DateTime.Now.ToString("yyyy-MM-dd h:mm:ss tt")}.csv\" file");

            //Save the action to the log
            Logger.Log(5, $"\"issued books.csv\" file is generated.");
        }
    }
}
