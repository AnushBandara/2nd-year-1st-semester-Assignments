﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library_Management_System
{
    internal static class CL_Interface
    {
        //Main interface of the programe
        public static int MainI_Numberd()
        {

            Console.WriteLine("\n\n");

            Console.WriteLine("Select your option : \n");
            Console.WriteLine("Add a book : \t\t1\nAdd a member : \t\t2\nIssue a book : \t\t3\nReturn a book : \t4\nView issued books : \t5\nEXIT this programe : \t0");

            Console.Write("\nEnter your option : ");
            int action = int.Parse(Console.ReadLine());


            //This will shure anythig other than 0,1,2,3,4,5 and -1 won't be passed.
            if (action < 0 || action > 5)
            {
                Console.WriteLine("You havent choose any available option.\nPlease select a one.");
                return -1;
            }
            else
            { 
                return action;
            }
        }

        //Interface pf the AddBook
        public static string[] AddBookI()
        {
            Console.WriteLine("\n\n\n---- Add a Book ----\n");

            Console.Write("Book id : ");
            string bID = Console.ReadLine();

            Console.Write("Book name : ");
            string bName = Console.ReadLine();

            Console.Write("ISBN : ");
            string bIsbn = Console.ReadLine();

            Console.Write("Author : ");
            string bAuthor = Console.ReadLine();

            string[] reutn_list = { bID, bName, bIsbn, bAuthor };

            return reutn_list;
        }

        //Interface of the AddMember
        public static string[] AddMemberI()
        {
            Console.WriteLine("\n\n\n---- Add a Member ----\n");

            Console.Write("Member ID : ");
            string mID = Console.ReadLine();

            Console.Write("Name : ");
            string mName = Console.ReadLine();

            Console.Write("Contact Number : ");
            string mContact = Console.ReadLine();

            string[] return_list = { mID, mName, mContact };
            return return_list;
        }

        //Interface of the IssueBook
        public static string[] IssueBookI()
        {
            Console.WriteLine("\n\n\n---- Issue a Book ----\n");

            Console.Write("Member ID : ");
            string mID = Console.ReadLine();

            Console.Write("Book ID : ");
            string bID = Console.ReadLine();

            string[] return_list = { mID, bID };
            return return_list;
        }

        //Interfac for ReturnBook
        public static string[] ReturnBookI()
        {
            Console.WriteLine("\n\n\n---- Return a Book ----\n");

            Console.Write("Book ID : ");
            string bID = Console.ReadLine();

            string[] return_list = { bID };
            return return_list;

        }

        //Interface for IssuedBooks
        public static void IssuedBooksI()
        {
            Console.WriteLine("\n\n\n---- Issued Books ----\n");
        }
    }
}
