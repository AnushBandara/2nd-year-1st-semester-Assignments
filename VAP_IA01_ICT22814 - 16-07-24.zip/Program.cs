﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library_Management_System
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to the Library System.");

            //The main loop.
            while (true)
            {
                int action = CL_Interface.MainI_Numberd();

                if (action == 0)
                {
                    //Close the application
                    Console.WriteLine("Good Bye !");
                    break;
                }
                else if (action == -1)
                {
                    continue;
                }
                else if (action == 1)
                {
                    //Add a book
                    Book.AddBook();
                }
                else if(action == 2)
                {
                    //Add a member
                    Member.AddMember();
                }
                else if (action == 3)
                {
                    //Issue a book
                    Book.IsueBook();
                }
                else if (action == 4)
                {
                    //Return a book
                    Book.ReturnBook();
                } 
                else if (action == 5)
                {
                    //Show returned books
                    Book.IssuedBooks();
                }
            }

        }
    }
}
