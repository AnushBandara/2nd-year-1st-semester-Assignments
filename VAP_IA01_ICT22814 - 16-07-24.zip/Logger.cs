﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;

namespace Library_Management_System
{
    internal static class Logger
    {
        static string workingDirectory = Environment.CurrentDirectory;

        //File Location
        static string filePath = Path.Combine(workingDirectory, "log.txt");

        //Headder
        static string header = "Date - Action Type - Action\n";


        public static void Log(int eventType, string eventData)
        {
            string type="";
            switch (eventType){
                case 1: type = "Add Book";break;

                case 2: type = "Add Member";break;

                case 3: type = "Issue Book"; break;

                case 4: type = "Return Book"; break;

                case 5: type = "Issued Books list"; break;

                case 6: type = "File Create"; break;
            }

            List<string> action = new List<string>();
            action.Add($"{DateTime.Now.ToString("yyyy-MM-dd h:mm:ss tt")} - {type} - {eventData}");

            //Saving the log.txt file
            Csv_RW.Csv_Writer(filePath, header, action, "log");
        }
    }
}
