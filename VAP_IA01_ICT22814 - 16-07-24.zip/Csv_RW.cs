﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;
using System.IO;


namespace Library_Management_System
{
    internal static class Csv_RW
    {
        public static void Csv_Writer(string path, string header, List<string> data, string name, bool clearWrite=false)
        {
            try
            {
                if (!File.Exists(path))
                {
                    //Creating the file if it dosen't exist.
                    File.AppendAllText(path, header);
                    Logger.Log(6, $"{path} is created");

                }

                //Appending data to the CSV file.
                if (clearWrite)
                {
                    File.WriteAllLines(path, data);
                }
                else
                {
                    File.AppendAllLines(path, data);
                }
                Console.WriteLine($"The {name} is saved.");

            }
            catch
            {
                Console.WriteLine($"The {name} havent saved. \nError !");
                throw;
            }
        }

        public static List<string> Csv_Reader(string path)
        {
            //Getting all the lines from the csv file.

            List<string> lines = new List<string>();
            lines = File.ReadAllLines(path).ToList();

            return lines;
        } 
    }
}
