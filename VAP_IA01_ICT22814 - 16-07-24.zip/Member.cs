﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library_Management_System
{
    internal static class Member
    {
        //Current directory
        static string workingDirectory = Environment.CurrentDirectory;

        static string filePath = Path.Combine(workingDirectory, "memberss.csv");

        public static void AddMember()
        {
            //Interface
            string[] inputList = CL_Interface.AddMemberI();


            string header = "Member ID,Name,Cotact Number\n";

            string data = inputList[0] + "," + inputList[1] + "," + inputList[2] + ",";
            List<string> writingData = new List<string>();
            writingData.Add(data);

            //Saving the members in members.csv file
            Csv_RW.Csv_Writer(filePath, header, writingData, $"\"{inputList[1]}\"");

            Logger.Log(2, $"{inputList[0]} user is added to the system.");

        }
        
    }
}
