﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace VP_LAB8_ICT22814
{
    public partial class frmQ1 : Form
    {
        string connectionString = @"Data Source=ANUSHKA;Initial Catalog=School;Integrated Security=True";
        public frmQ1()
        {
            InitializeComponent();
        }

        private void btnShowData_Click(object sender, EventArgs e)
        {
            using(SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();

                SqlDataAdapter sda = new SqlDataAdapter("SELECT * FROM student_details", conn);
                DataTable dt = new DataTable();

                sda.Fill(dt);
                dgvStudentDetails.DataSource = dt;
            }
        }
    }
}
