﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace VP_LAB8_ICT22814
{
    public partial class frmQ2 : Form
    {

        public frmQ2()
        {
            InitializeComponent();
            this.CenterToScreen();
        }

        SqlConnection conn = new SqlConnection("Data Source=ANUSHKA;Initial Catalog=DemoDB;Integrated Security=True");
        SqlCommand cmd;
        SqlDataAdapter sda;
        DataTable dt;

        private void btnClose_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Load_data()
        {
            cmd = new SqlCommand("SELECT * FROM [User]", conn);
            
            sda = new SqlDataAdapter();
            sda.SelectCommand = cmd;

            dt = new DataTable();
            dt.Clear();
            sda.Fill(dt);

            dgvData.DataSource = dt;
        }

        private void Nclear()
        {
            txtbID.Text = txtbName.Text = txtbAddress.Text = "";
        }

        private void dgvData_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int index;
            index = e.RowIndex;

            DataGridViewRow selectedRow = dgvData.Rows[index];

            txtbID.Text = selectedRow.Cells[0].Value.ToString();
            txtbName.Text = selectedRow.Cells[1].Value.ToString();
            txtbAddress.Text = selectedRow.Cells[2].Value.ToString();
        }

        private void Parameters()
        {
            cmd.Parameters.AddWithValue("ID", txtbID.Text);
            cmd.Parameters.AddWithValue("Name", txtbName.Text);
            cmd.Parameters.AddWithValue("Address", txtbAddress.Text);

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if(String.IsNullOrEmpty(txtbID.Text) || String.IsNullOrEmpty(txtbName.Text) || String.IsNullOrEmpty(txtbAddress.Text))
            {
                MessageBox.Show("Complete all the required fields.");
                return;
            }
            else
            {
                cmd = new SqlCommand("INSERT INTO [USER] VALUES (@ID, @Name, @Address)", conn);
                Parameters();

                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();

                Load_data();
                MessageBox.Show("The reord inserted Succesfully.");

                Nclear();
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            cmd = new SqlCommand("SELECT * FROM [USER] WHERE Id LIKE @search + '%' OR Name LIKE @search + '%' OR Address LIKE @search + '%'", conn);
            cmd.Parameters.AddWithValue("search", txtbSearch.Text);

            sda = new SqlDataAdapter();
            sda.SelectCommand = cmd;

            dt = new DataTable();
            dt.Clear();
            sda.Fill(dt);

            dgvData.DataSource = dt;
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(txtbID.Text) || String.IsNullOrEmpty(txtbName.Text) || String.IsNullOrEmpty(txtbAddress.Text))
            {
                MessageBox.Show("Complete all the required fields.");
                return;
            }
            else
            {
                cmd = new SqlCommand("UPDATE [USER] SET Id=@ID, Name = @Name, Address = @Address WHERE Id=@ID", conn);
                Parameters();

                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();

                Load_data();
                MessageBox.Show("The reord updated Succesfully.");

                Nclear();
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            cmd = new SqlCommand("DELETE FROM [User] WHERE Id=@ID", conn);
            Parameters();

            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();

            Load_data();
            MessageBox.Show("The rechord updated Succesfully.");

            Nclear();
        }

        private void btnNew_Click(object sender, EventArgs e)
        {
            Nclear();
            Load_data();
        }
    }
}
