﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Results_Calc
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            int marks = int.Parse(txtbMarks.Text);
            string title = "Your Division";

            //Check for error iputs
            if(marks < 0 || marks > 100)
            {
                MessageBox.Show("Please enter the marks between 0 to 100", title);
            }else
            {
                //Calculating the Grades
                if (marks >= 75)
                {
                    MessageBox.Show("You are in First Class Divison.", title);
                }
                else if (marks >= 60)
                {
                    MessageBox.Show("You are in Upper Second Class Divison.", title);
                }
                else if (marks >= 50)
                {
                    MessageBox.Show("You are in Lower Second Class Divison.", title);
                }
                else if (marks >= 40)
                {
                    MessageBox.Show("You are in General Pass Divison.", title);
                }
                else if (marks < 40)
                {
                    MessageBox.Show("You are in Fail Divison.", title);
                }
            }

            

        }
    }
}
