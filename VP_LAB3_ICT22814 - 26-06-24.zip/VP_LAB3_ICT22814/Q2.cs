﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VP_LAB3_ICT22814
{
    internal class Q2
    {
        static void Main(string[] args)
        {
            Console.Write("Enter your number: ");
            int num = int.Parse(Console.ReadLine());

            if (num > 0)
            {
                int factorial = 1;

                for (int i = num; i > 0; i--)
                {
                    factorial *= i;
                }

                Console.WriteLine(num + "! = " + factorial);
            }
            else
            {
                Console.WriteLine("You enterd a negetive number.");
            }

            Console.ReadKey();
        }
    }
}
