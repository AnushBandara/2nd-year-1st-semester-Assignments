﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VP_LAB3_ICT22814
{
    internal class Q5
    {
        static void Main(string[] args)
        {
            Console.Write("Enter the number of steps: ");
            int stepCount = int.Parse(Console.ReadLine());

            FibonachiBuilder(stepCount);

            Console.ReadKey();
        }

        static void FibonachiBuilder(int stepCount)
        {
            int num1 = 0;
            int num2 = 1;

            int step = 0;

            Console.Write(num1 + ", " + num2);

            for (int i = 0; i < stepCount-2; i++)
            {
                step = num1 + num2;
                Console.Write(", "+ step);

                num1 = num2;
                num2 = step;
                
            }
        }
    }
}
