﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VP_LAB3_ICT22814
{
    internal class Q3
    {
        static void Main(string[] args)
        {
            for (int i = 1; i <= 14; i++)
            {
                Console.WriteLine(i + "X : ");

                for (int j = 1; j <= 12; j++)
                {
                    Console.WriteLine(i + "x" + j + " = " + i * j);
                }

                Console.WriteLine("\n\n");
            }

            Console.ReadKey();
        }
    }
}
