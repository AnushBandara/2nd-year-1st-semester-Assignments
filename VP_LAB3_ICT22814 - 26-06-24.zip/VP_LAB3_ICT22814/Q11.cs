﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VP_LAB3_ICT22814
{
    // Define the Vehicle class
    public class Vehicle
    {
        // Attributes of the Vehicle class
        private string brandName;
        private string model;
        private string color;

        // Default constructor
        public Vehicle()
        {
            brandName = "Default Brand";
            model = "Default Model";
            color = "Default Color";
        }

        // Parameterized constructor
        public Vehicle(string brandName, string model, string color)
        {
            this.brandName = brandName;
            this.model = model;
            this.color = color;
        }

        // Properties to access the private fields
        public string BrandName
        {
            get { return brandName; }
            set { brandName = value; }
        }

        public string Model
        {
            get { return model; }
            set { model = value; }
        }

        public string Color
        {
            get { return color; }
            set { color = value; }
        }

        // Method to simulate driving fast
        public void DriveFast()
        {
            Console.WriteLine($"{brandName} {model} is driving fast!");
        }

        // Method to simulate applying the brake
        public void ApplyBrake()
        {
            Console.WriteLine($"{brandName} {model} is applying the brake.");
        }
    }

    // Main Program
    internal class Q11
    {
        static void Main(string[] args)
        {

            // Create an instance of Vehicle using the parameterized constructor
            Vehicle myVehicle = new Vehicle("Toyota", "Corolla", "Red");

            // Display vehicle details
            Console.WriteLine($"Brand: {myVehicle.BrandName}, Model: {myVehicle.Model}, Color: {myVehicle.Color}");

            // Call methods
            myVehicle.DriveFast();
            myVehicle.ApplyBrake();

            Console.ReadKey();
        }
    }

}
