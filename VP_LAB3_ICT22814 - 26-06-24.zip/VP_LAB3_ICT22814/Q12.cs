﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VP_LAB3_ICT22814
{
    // Define the Animal class
    public class Animal
    {
        // Attributes of the Animal class
        protected string Name;
        protected int Age;
        protected string Species;

        // Default constructor
        public Animal()
        {
            Name = "Unknown";
            Age = 0;
            Species = "Unknown";
        }

        // Parameterized constructor
        public Animal(string name, int age, string species)
        {
            Name = name;
            Age = age;
            Species = species;
        }

        // Method to make the animal speak
        public void Speak()
        {
            Console.WriteLine($"{Name} is making a sound.");
        }

        // Method to display animal details
        public void DisplayDetails()
        {
            Console.WriteLine($"Name: {Name}, Age: {Age}, Species: {Species}");
        }
    }

    // Define the Dog class that inherits from Animal
    public class Dog : Animal
    {
        // Additional attribute for the Dog class
        public string Breed;

        // Default constructor
        public Dog() : base()
        {
            Breed = "Unknown Breed";
        }

        // Parameterized constructor
        public Dog(string name, int age, string species, string breed) : base(name, age, species)
        {
            Breed = breed;
        }

        // Method to make the dog bark
        public void Bark()
        {
            Console.WriteLine($"{Name} is barking.");
        }

        // Override the Speak method
        public new void Speak()
        {
            Console.WriteLine($"{Name} says Woof!");
        }
    }

    // Main Program
    internal class Q12
    {
        static void Main(string[] args)
        {
            // Create an instance of Dog
            Dog myDog = new Dog("Buddy", 3, "Canine", "Golden Retriever");
            myDog.DisplayDetails();
            myDog.Speak();  // Calls the overridden Speak method in Dog
            myDog.Bark();   // Calls the Bark method specific to Dog

            Console.ReadKey();
        }
    }
}
