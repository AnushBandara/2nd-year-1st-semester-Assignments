﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VP_LAB3_ICT22814
{
    // Define the Customer class
    public class Customer
    {
        // Attributes of the Customer class
        private string name;
        private string address;
        private string order;

        // Default constructor
        public Customer()
        {
            name = "Default Name";
            address = "Default Address";
            order = "Default Order";
        }

        // Properties to access the private fields
        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public string Address
        {
            get { return address; }
            set { address = value; }
        }

        public string Order
        {
            get { return order; }
            set { order = value; }
        }

        // Method to display customer details
        public void DisplayCustomerDetails()
        {
            Console.WriteLine($"Name: {Name}");
            Console.WriteLine($"Address: {Address}");
            Console.WriteLine($"Order: {Order}");
        }
    }

    // Main Program
    internal class Q10
    {
        static void Main(string[] args)
        {
            // Create an instance of Customer using the default constructor
            Customer customer = new Customer();

            // Update customer details
            customer.Name = "John Doe";
            customer.Address = "789 Customer Blvd";
            customer.Order = "Order #12345";

            // Display updated customer details
            customer.DisplayCustomerDetails();

            Console.ReadKey();
        }
    }
}
