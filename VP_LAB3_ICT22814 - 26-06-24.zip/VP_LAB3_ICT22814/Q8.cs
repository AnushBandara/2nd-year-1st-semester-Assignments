﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VP_LAB3_ICT22814
{
    internal class Q8
    {
        static void Main(string[] args)
        {
            string[] words = {"Anushka", "Sudeera", "Bandara"};

            Console.WriteLine("Longest word: "+ FindLongestWord(words));
            Console.ReadKey();


        }

        static string FindLongestWord(string[] words)
        {
            string longestWord="";
            int len = 0;

            foreach (string word in words)
            {
                if (word.Length > len)
                {
                    longestWord = word;
                }
            }

            return longestWord;
        }

    }
}
