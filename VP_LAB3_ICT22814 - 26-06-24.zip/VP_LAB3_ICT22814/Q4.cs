﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VP_LAB3_ICT22814
{
    internal class Q4
    {
        static void Main(string[] args)
        {
            Console.Write("Enter your text: ");
            String word = Console.ReadLine();

            int len = word.Length;

            for (int i = 0; i < len / 2; i++)
            {
                if (word[i] != word[(len - 1) - i])
                {
                    Console.WriteLine(word + " is not a palidrome.");
                    break;
                }

                if (i == len / 2 - 1)
                {
                    Console.WriteLine(word + " is a palidrome.");
                }
            }

            Console.ReadKey();

        }
    }
}
