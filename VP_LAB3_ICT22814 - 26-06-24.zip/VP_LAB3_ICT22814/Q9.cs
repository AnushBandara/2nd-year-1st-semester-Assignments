﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VP_LAB3_ICT22814
{
    // Define the Employee class
    public class Employee
    {
        // Attributes of the Employee class
        public string Name { get; set; }
        public int Age { get; set; }
        public string Address { get; set; }

        // Constructor to initialize the Employee attributes
        public Employee(string name, int age, string address)
        {
            Name = name;
            Age = age;
            Address = address;
        }

        // Method to display the team message
        public virtual void DisplayTeamMessage()
        {
            // Default implementation (could be overridden by derived classes)
        }
    }

    // Derived class for Admin Team
    public class AdminTeam : Employee
    {
        public AdminTeam(string name, int age, string address)
            : base(name, age, address)
        {
        }

        // Override the DisplayTeamMessage method
        public override void DisplayTeamMessage()
        {
            Console.WriteLine("We belong to Administration");
        }
    }

    // Derived class for Marketing Team
    public class MarketingTeam : Employee
    {
        public MarketingTeam(string name, int age, string address)
            : base(name, age, address)
        {
        }

        // Override the DisplayTeamMessage method
        public override void DisplayTeamMessage()
        {
            Console.WriteLine("We belong to Marketing");
        }
    }

    // Main Program
    internal class Q9
    {
        static void Main(string[] args)
        {
            // Create an instance of AdminTeam
            AdminTeam adminTeam = new AdminTeam("Alice", 30, "123 Admin St");
            // Display message for AdminTeam
            adminTeam.DisplayTeamMessage();

            // Create an instance of MarketingTeam
            MarketingTeam marketingTeam = new MarketingTeam("Bob", 28, "456 Marketing Ave");
            // Display message for MarketingTeam
            marketingTeam.DisplayTeamMessage();

            Console.ReadKey();
        }
    }
}
