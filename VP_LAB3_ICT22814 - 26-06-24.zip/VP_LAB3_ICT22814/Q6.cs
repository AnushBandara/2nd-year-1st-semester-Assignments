﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VP_LAB3_ICT22814
{
    internal class Q6
    {
        static void Main(string[] args)
        {
            int[] arr = { 1, 2, 3, 4, 5, 6, 7, 8 };

            int[] minMax = FindMinMax(arr);
            Console.WriteLine("min: " + minMax[0]);
            Console.WriteLine("max: " + minMax[1]);

            Console.ReadKey();
        }

        static int[] FindMinMax(int[] arr) {
            int[] minMax = { arr[0], arr[0] };

            for (int i = 0; i < arr.Length; i++)
            {
                if (arr[i] < minMax[0])
                {
                    minMax[0] = arr[i];
                }

                if (arr[i] > minMax[1])
                {
                    minMax[1] = arr[i];
                }
            }

            return minMax;
        }



    }
}
