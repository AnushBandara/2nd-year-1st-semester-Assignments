﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VP_LAB3_ICT22814
{
    internal class Q7
    {
        static void Main(string[] args)
        {
            int[] arr = { 1, 2, 3, 4, 5, 6, 7, 8 };

            int[] avgSum = FindAvgSum(arr);
            Console.WriteLine("Average: " + avgSum[0]);
            Console.WriteLine("Sum: " + avgSum[1]);

            Console.ReadKey();

        }

        static int[] FindAvgSum(int[] arr)
        {
            int[] avgSum = { 0, 0};

            for (int i = 0; i < arr.Length; i++)
            {
                avgSum[1] += arr[i];
            }

            avgSum[0] = avgSum[1] / arr.Length;

            return avgSum;
        }

    }
}
