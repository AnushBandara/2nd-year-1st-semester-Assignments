﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter the length of the base : ");
            float t_base = float.Parse(Console.ReadLine());

            Console.Write("Enter the height : ");
            float t_height = float.Parse(Console.ReadLine());

            float t_area = (float)(0.5 * t_base * t_height);

            Console.WriteLine("Area of the triangle : " + t_area);

            Console.ReadKey();
        }
    }
}
