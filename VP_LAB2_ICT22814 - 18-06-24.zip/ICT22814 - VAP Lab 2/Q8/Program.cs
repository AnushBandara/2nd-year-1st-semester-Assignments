﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q8
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter number 1 : ");
            float num1 = float.Parse(Console.ReadLine());

            Console.Write("Enter number 2 : ");
            float num2 = float.Parse(Console.ReadLine());

            Console.Write("Enter number 3 : ");
            float num3 = float.Parse(Console.ReadLine());

            float average = (float)(num1 + num2 + num3)/3;

            Console.WriteLine("Average : "+ average);

            Console.ReadKey();


        }
    }
}
