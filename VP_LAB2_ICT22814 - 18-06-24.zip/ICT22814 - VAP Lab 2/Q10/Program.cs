﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q10
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter number 1 : ");
            float num1 = float.Parse(Console.ReadLine());

            Console.Write("Enter number 2 : ");
            float num2 = float.Parse(Console.ReadLine());

            Console.Write("Enter number 3 : ");
            float num3 = float.Parse(Console.ReadLine());

            if (num1 > num2)
            {
                if (num1 > num3)
                {
                    Console.WriteLine(num1 + " is the biggest number.");
                }
                else
                {
                    Console.WriteLine(num3 + " is the biggest number.");
                }
            }else if (num2 > num3)
            {
                Console.WriteLine(num2 + " is the biggest number.");
            }
            else
            {
                Console.WriteLine(num3 + " is the biggest number.");
            }

            Console.ReadKey();
        }
    }
}
