﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q7
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter te radius of te circle : ");
            float radius = float.Parse(Console.ReadLine());

            float area = (float)22/7*radius*radius;
            float perimeter = (float)2*22/7*radius;

            Console.WriteLine("Area : " + area);
            Console.WriteLine("Perimeter : " + perimeter);

            Console.ReadKey();
        }
    }
}
