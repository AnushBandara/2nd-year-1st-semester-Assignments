﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter an Integer: ");
            int num = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("The integer you entered is "+num);
            Console.ReadKey();
        }
    }
}
