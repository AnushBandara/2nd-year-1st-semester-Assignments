//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {

        //The dummy list
        Integer[] list = {1,2,3,4,5,6,7,8,9,10};
        System.out.print("The list : ");
        for (int i = 0; i < list.length; i++) System.out.print(list[i] + ", ");

        //The index of the element to delete
        int deleteIndex = 5;
        System.out.println("\nThe deletion index : "+deleteIndex);
        System.out.println("The deletion element :"+list[deleteIndex]);

        //Removing the element from the list and reanging the list.
        for (int i = deleteIndex+1; i < list.length; i++) {
            list[i-1] = list[i];
        }
        list[list.length-1] = null;

        //Printing the updated list
        System.out.print("\nThe updated list : ");
        for (int i = 0; i < list.length; i++) System.out.print(list[i] + ", ");

    }
}