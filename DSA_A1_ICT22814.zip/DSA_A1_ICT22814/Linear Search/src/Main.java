//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {

        //Sample list
        int [] list = {1,6,2,8,4,0,2,5,34,65,23,76,98,0};
        System.out.print("List : ");
        for (int i=0; i< list.length; i++) System.out.print(list[i] + ", ");

        //Number to search
        int searchKey = 98;
        System.out.println("\nSearch key : " + searchKey);

        //Calling Linear search method
        int location = LinearSearch(list, searchKey);

        //Printing the location
        if (location != -1) {
            System.out.println("The search key is at " + location);
        }else{
            //If the search has not found
            System.out.println("The search key is not in the list.");
        }

    }

    public static int LinearSearch(int[] list, int searchKey){

        for (int i = 0; i < list.length; i++) {
            //Check each element and campare it with the searchKey.
            if (list[i] == searchKey) {
                //If the search key found, it will return its index.
                return i;
            }
        }

        //If the searchKey hasn't found then it will return -1.
        return -1;
    }

}